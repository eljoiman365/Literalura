package com.electronicbooks.Literalura.BaseDeDatos.RepositoyQuerys;

import com.electronicbooks.Literalura.Datos.Local.Autor;
import jakarta.persistence.Id;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AutorRepository extends JpaRepository <Autor, Long> {
    List<Autor> findAll();
    @Query("SELECT a FROM Autor a " + "WHERE a.fechaNacimiento <= :input AND (a.fechaFallecimiento IS NULL OR a.fechaFallecimiento > :input)")
    List<Autor> buscarPorRangoAno(Integer input);
}
