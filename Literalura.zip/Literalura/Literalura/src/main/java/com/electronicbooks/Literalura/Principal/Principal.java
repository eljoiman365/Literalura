package com.electronicbooks.Literalura.Principal;

import com.electronicbooks.Literalura.BaseDeDatos.RepositoyQuerys.AutorRepository;
import com.electronicbooks.Literalura.BaseDeDatos.RepositoyQuerys.LibroRepository;
import com.electronicbooks.Literalura.Datos.Api.DatosAutor;
import com.electronicbooks.Literalura.Datos.Api.DatosGenerales;
import com.electronicbooks.Literalura.Datos.Api.DatosLibro;
import com.electronicbooks.Literalura.Datos.Local.Autor;
import com.electronicbooks.Literalura.Datos.Local.Libro;
import com.electronicbooks.Literalura.Operaciones.ConsumoApi;
import com.electronicbooks.Literalura.Operaciones.ConvertidorDatos;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


public class Principal {

    private AutorRepository aRepository;
    private LibroRepository lRepository;

    public Principal() {};

    public Principal(AutorRepository aRepository, LibroRepository lRepository) {

        this.aRepository = aRepository;
        this.lRepository = lRepository;
    }

    ConsumoApi consumoApi = new ConsumoApi();
    ConvertidorDatos convertidorDatos = new ConvertidorDatos();
    Scanner teclado = new Scanner(System.in);
    ;
    private String json;
    private final String LINKBASE = "https://gutendex.com/books/?search=";


    public void main() {

        try {
            System.out.println("""
          
                *** Dígita el número 1 para ingresar al menú principal o el número 0 para finalizar el programa ***
                ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::""");

            var input = teclado.nextInt();
            teclado.nextLine();


            while (input != 1 && input != 0) {
                System.out.println("*** Ingresa un número válido ***");
            }

            while (input != 0) {
                System.out.println("""
                        *** Ingresa el un número de acuerdo a la acción que deseas realizar ***
                        :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                        
                        ** 1- Guardar libro nuevo (agregar registro)
                        ** 2- Listar libros registrados
                        ** 3- Listar autores registrados
                        ** 4- Buscar autores vivos en un determinado año
                        ** 5- Listar libros por idioma
                        ** 0- salir 
                        
                        """);

                System.out.println("""
                        *** Digita el número de la opción deseada ***
                        :::::::::::::::::::::::::::::::::::::::::::::""");
                input = teclado.nextInt();
                teclado.nextLine();

                switch (input) {
                    case 1:
                        consultaWeb();
                        break;
                    case 2:
                        busquedaLibros();
                        break;
                    case 3:
                        busquedaAutor();
                        break;
                    case 4:
                        busquedaFecha();
                        break;
                    case 5:
                        System.out.println("""
                                *** Ingresa una de las siguientes abreviaciones para listar los libros guardados por idioma ***
                                :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                                
                                es - español
                                en - inglés
                                fr - frances
                                pt - portugués
                                *** Otro valor (ingresar abreviatura)""");
                        busquedaIdioma();
                        break;
                    case 0:
                        return;
                }
                System.out.println("""
                        
                        ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                        *** Ingresa un número aleatorio para regresar al menú principal ***
                        *** Ingresa el número 0 para finalizar ***
                        ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                        """);
                input = teclado.nextInt();
                teclado.nextLine();
            }
        } catch(InputMismatchException e){
            System.out.println("""
                        
                        *** El dato ingresado es invalido, recuerda solo digitar números ***
                        ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                        """);
        }
    }
    public void consultaWeb() {

        try {
        System.out.println("""
                *** Ingresa el nombre del libro que deseas buscar ***
                :::::::::::::::::::::::::::::::::::::::::::::::::::::
                """);
        String valorInput = teclado.nextLine();
        json = consumoApi.obtenerDatos(LINKBASE + valorInput.replace(" ", "+"));
        DatosGenerales datosGenerales = convertidorDatos.convierteDatos(json, DatosGenerales.class);

        List<DatosLibro> listaDatosLibro = datosGenerales.datosLibros();
        List<DatosAutor> listaDatosAutor = datosGenerales.datosLibros().get(0).datosAutor();
        List<Libro> listaLibros = new ArrayList<>();
        List<Autor> listaAutor = new ArrayList<>();

        for (DatosLibro iteracion : listaDatosLibro) {
            Libro libro = new Libro(iteracion, iteracion.datosAutor().get(0).nombre());
            listaLibros.add(libro);
        }
        for (DatosAutor iteracion : listaDatosAutor) {
            Autor autor = new Autor(iteracion);
            listaAutor.add(autor);
        }
            lRepository.saveAll(listaLibros);
            aRepository.saveAll(listaAutor);
            System.out.println("""
                    *** Datos guardados con éxito!! ***
                    :::::::::::::::::::::::::::::::::::
                    """);
            System.out.println("""
                    *** Datos del libro ***
                    :::::::::::::::::::::::::::::::::::
                    """);
            listaLibros.forEach(System.out::println);
            System.out.println("""
                    
                    *** Datos del autor ***
                    :::::::::::::::::::::::::::::::::::
                    """);
            listaAutor.forEach(System.out::println);
        } catch (DataIntegrityViolationException | IndexOutOfBoundsException e) {
                System.out.println("""
                    
                    *** No ha sido posible guardar el registro debido a uno de los siguientes errores ***
                    
                    1 - El libro ya se encuentra en la base de datos
                    2 - El libro no existe en el repositorio de la API
                    3 - El dato ingresado no es válido
                    
                    :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    """);
        }
    }
        public void busquedaLibros () {

            System.out.println("""
                    
                    *** Lista de libros registrados en la base de datos ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
                    """);

            var busquedaCompletaLibro = lRepository.findAll();
            busquedaCompletaLibro.forEach(System.out::println);

        }
        public void busquedaAutor () {

            System.out.println("""
                    
                    *** Lista de autores registrados en la base de datos ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
                    """);

            var busquedaCompletaAutor = aRepository.findAll();
            busquedaCompletaAutor.forEach(System.out::println);
        }
        public void busquedaIdioma () {

            System.out.println("""
                    
                    *** Ingresa el idioma sobre el cual deseas buscar el libro ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    """);
            String valorInput = teclado.nextLine();

            while (!valorInput.matches("[a-zA-Z]+")){
                System.out.println("""
                        *** Ingresa un valor solo con letras acorde al menú anterior ***
                        """);
                valorInput = teclado.nextLine();
            }
            var busquedaPorIdioma = lRepository.findByIdioma(valorInput);

            List <String> listaPrueba = new ArrayList<String>();

            if (busquedaPorIdioma.size() == listaPrueba.size()) {
                System.out.println("""
                        
                        *** No hay registros guardados con el idioma indicado ***
                        """);
            }else {
                busquedaPorIdioma.forEach(System.out::println);
            }
        }
        public void busquedaFecha () {

            System.out.println("""
                    *** Ingresa un año para buscar la lista de autores ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    """);

                var valorInput = teclado.nextInt();
                var busquedaPorFecha = aRepository.buscarPorRangoAno(valorInput);

                List<Integer> valorNull = new ArrayList<>();

            if (busquedaPorFecha.size() == valorNull.size()) {

                System.out.println("""
                   
                    *** No se han encontrado autores en este periodo de tiempo ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    """);
            }else
                System.out.println("""
                    
                    *** Lista de autores encontrados en el periodo de tiempo indicado: ***
                    ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    """);
            busquedaPorFecha.forEach(System.out::println);
    }
}




