package com.electronicbooks.Literalura.Principal;

public class Test {

    public static void main(String[] args) {

        Principal principal = new Principal();

        principal.main();

    }
}
