package com.electronicbooks.Literalura.Datos.Local;

import com.electronicbooks.Literalura.Datos.Api.DatosAutor;
import jakarta.persistence.*;

@Entity
@Table(name = "autores", uniqueConstraints = {
        @UniqueConstraint(columnNames = "nombre")
})

public class Autor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private Integer fechaNacimiento;
    private Integer fechaFallecimiento;

    public Autor (){};

    public Autor(DatosAutor datosAutor){

        this.nombre = datosAutor.nombre();
        this.fechaNacimiento = datosAutor.anoNacimiento();
        this.fechaFallecimiento = datosAutor.anoFallecimiento();

    }

    @Override
    public String toString() {
        return "-----------AUTOR----------\n" +
                "Nombre: " + nombre + "\n" +
                "Fecha de nacimiento: " + fechaNacimiento + "\n" +
                "Fecha de fallecimiento: " + fechaFallecimiento + "\n" +
                "-------------------------"
                ;
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getFechaFallecimiento() {
        return fechaFallecimiento;
    }

    public Integer getFechaNacimiento() {
        return fechaNacimiento;
    }
}
