package com.electronicbooks.Literalura.BaseDeDatos.RepositoyQuerys;

import com.electronicbooks.Literalura.Datos.Local.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface LibroRepository extends JpaRepository<Libro,Long> {

    List<Libro> findByTitulo(String titulo);
    List<Libro> findAll();
    List<Libro> findByIdioma(String idioma);

}
