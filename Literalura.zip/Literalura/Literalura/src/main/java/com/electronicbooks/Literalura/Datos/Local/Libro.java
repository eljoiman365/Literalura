package com.electronicbooks.Literalura.Datos.Local;

import com.electronicbooks.Literalura.Datos.Api.DatosLibro;
import jakarta.persistence.*;

@Entity
@Table(name = "libros", uniqueConstraints = {
        @UniqueConstraint(columnNames = "titulo" )
})

public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titulo;
    private String idioma;
    private Integer descargasTotales;
    private String autor;

    public Libro (){};

    public Libro(DatosLibro datosLibro, String autor) {
        this.titulo = datosLibro.titulo();
        this.idioma = datosLibro.idioma().get(0).replace("[ ]"," ");
        this.descargasTotales = datosLibro.cantidadDescargas();
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "----------LIBRO---------\n" +
                "Título: " + titulo + "\n" +
                "Autor: " + autor + "\n" +
                "Idioma: " + idioma + "\n" +
                "Cantidad de descargas: " + descargasTotales + "\n" +
                "-----------------------"
                ;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getIdioma() {
        return idioma;
    }

    public Integer getDescargasTotales() {
        return descargasTotales;
    }

    public String getAutor() {
        return autor;
    }

    public Long getId() {
        return id;
    }
}
