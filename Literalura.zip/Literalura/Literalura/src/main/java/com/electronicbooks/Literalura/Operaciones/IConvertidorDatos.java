package com.electronicbooks.Literalura.Operaciones;

public interface IConvertidorDatos {

    <T> T convierteDatos(String json, Class<T> clase);

}
