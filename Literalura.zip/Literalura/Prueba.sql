select * from autores
select * from Libros

select * from autores where fecha between 20 and 40